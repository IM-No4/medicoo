import { ActionKey } from './action.types';

export const ActionRegistry: Record<ActionKey, any> = {
  OPEN_GLOBAL_SEARCH: {
    stack: 'SearchStack',
    screen: 'SearchHome',
  },

  OPEN_DOCTOR_LIST: {
    stack: 'DoctorStack',
    screen: 'DoctorList',
  },
  OPEN_DOCTOR_DETAIL: {
    stack: 'DoctorStack',
    screen: 'DoctorDetail',
  },

  OPEN_PHARMACY_LIST: {
    stack: 'PharmacyStack',
    screen: 'PharmacyList',
  },
  
  OPEN_PHARMACY: {
    stack: 'PharmacyStack',
    screen: 'PharmacyDetail',
  },
  OPEN_CART: {
    stack: 'CartStack',
    screen: 'CartScreen',
  },
  OPEN_LABS: {
    stack: 'LabStack',
    screen: 'LabList',
  },
  OPEN_LAB_TESTS: {
    stack: 'LabStack',
    screen: 'LabTestList',
  },

  OPEN_HOSPITALS: {
    stack: 'HospitalStack',
    screen: 'HospitalList',
  },

  OPEN_AMBULANCE: {
    stack: 'AmbulanceStack',
    screen: 'AmbulanceHome',
  },

  OPEN_HOMECARE: {
    stack: 'HomeCareStack',
    screen: 'HomeCareHome',
  },

  OPEN_RECORDS: {
    tab: 'Records',
  },
  UPLOAD_RECORD: {
    stack: 'RecordsStack',
    screen: 'UploadRecord',
  },

  OPEN_PROFILE: {
    tab: 'Profile',
  },
  OPEN_CALENDAR: {
    tab: 'Calendar',
  },
  OPEN_HEALTH: {
    tab: 'Health',
  },
  OPEN_NOTIFICATIONS: {
    stack: 'HomeStack',
    screen: 'Notifications',
  },
  ADD_MEDICINE_FROM_SEARCH: {},
  OPEN_ADDRESS_SELECTOR: {},
};
