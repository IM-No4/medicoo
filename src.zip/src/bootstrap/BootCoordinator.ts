import AsyncStorage from '@react-native-async-storage/async-storage';
import { getToken } from '../utils/tokenManagement';
import { bootFail, bootStart, bootSuccess } from './boot.slice';

export const runBootSequence = async (dispatch: any) => {
  try {
    dispatch(bootStart());

    const token = await getToken('access_token');
    const onboarding = await AsyncStorage.getItem('onboarding_completed');

    dispatch(
      bootSuccess({
        isAuthenticated: !!token,
        onboardingCompleted: onboarding === 'true',
        initialRoute: token ? 'MainTabs' : 'Login',
      })
    );
  } catch (e) {
    dispatch(bootFail());
  }
};
