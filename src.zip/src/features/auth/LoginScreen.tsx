import React, { useState } from 'react';
import {
    ActivityIndicator,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from 'react-native';
import { useDispatch } from 'react-redux';

import { loginSuccess } from '../../redux/slices/authSlice';
import { sendOtp, verifyOtp } from '../../services/api/auth.api';
import { getDeviceId, getFCMToken } from '../../utils/deviceUtils';
import { setToken } from '../../utils/tokenManagement';

export default function LoginScreen() {
  const dispatch = useDispatch();

  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'PHONE' | 'OTP'>('PHONE');
  const [loading, setLoading] = useState(false);

  const handleSendOtp = async () => {
    if (phone.length !== 10) return;
    setLoading(true);
    try {
      await sendOtp(phone);
      setStep('OTP');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (otp.length !== 6) return;
    setLoading(true);
    try {
      const fcmToken = await getFCMToken();
      const deviceId = getDeviceId();
      const res = await verifyOtp(phone, otp, fcmToken, deviceId);

      if (res?.access_token) {
        await setToken('access_token', res.access_token);
        dispatch(loginSuccess({ token: res.access_token, onboardingComplete: res.onboardingComplete }));
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>

      {step === 'PHONE' ? (
        <>
          <TextInput
            placeholder="Mobile Number"
            keyboardType="phone-pad"
            value={phone}
            onChangeText={setPhone}
            style={styles.input}
          />
          <TouchableOpacity onPress={handleSendOtp} style={styles.button}>
            {loading ? <ActivityIndicator /> : <Text>Send OTP</Text>}
          </TouchableOpacity>
        </>
      ) : (
        <>
          <TextInput
            placeholder="OTP"
            keyboardType="number-pad"
            value={otp}
            onChangeText={setOtp}
            style={styles.input}
          />
          <TouchableOpacity onPress={handleVerifyOtp} style={styles.button}>
            {loading ? <ActivityIndicator /> : <Text>Verify</Text>}
          </TouchableOpacity>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 20 },
  title: { fontSize: 22, textAlign: 'center', marginBottom: 20 },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
  },
  button: {
    backgroundColor: '#1a998e',
    padding: 14,
    alignItems: 'center',
    borderRadius: 8,
  },
});
