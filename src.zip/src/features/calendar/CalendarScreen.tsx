import React, { useEffect, useState } from 'react';
import { ScrollView, Text, TouchableOpacity, View } from 'react-native';
import { styles } from './styles';

// Components
import AppointmentCard from './components/AppointmentCard';
import CalendarHeader from './components/CalendarHeader';
import CalendarModal from './components/CalendarModal'; // <--- Import Modal
import CalendarSkeleton from './components/CalendarSkeleton';
import DateStrip from './components/DateStrip';
import MedicineCard from './components/MedicineCard';
import ProgressCard from './components/ProgressCard';

import { loadCalendarData } from '@/src/redux/slices/calendarSlice';
import { useDispatch, useSelector } from 'react-redux';
import EmptyState from '../../components/layout/EmptyState';
import ErrorState from '../../components/layout/ErrorState';

export default function CalendarScreen() {
  const dispatch = useDispatch();
  const { data, loading, error } = useSelector((state) => state.calendar);
  
  // State for the Calendar Modal
  const [isCalendarVisible, setCalendarVisible] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());

  useEffect(() => {
    dispatch(loadCalendarData());
  }, [dispatch]);

  const statusBarProps = {
    barStyle: "dark-content",
    backgroundColor: "transparent",
    translucent: true,
  };

  /* ---------------- ERROR ---------------- */
  if (error) {
    return (
      <View style={styles.screen}>
        <CalendarHeader onOpenCalendar={() => setCalendarVisible(true)} />
        <ErrorState message={error} onRetry={() => dispatch(loadCalendarData())} />
      </View>
    );
  }

  /* ---------------- LOADING ---------------- */
  if (loading || !data) {
    return (
      <View style={styles.screen}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <CalendarHeader onOpenCalendar={() => setCalendarVisible(true)} />
          <DateStrip />
          <CalendarSkeleton />
        </ScrollView>
      </View>
    );
  }

  /* ---------------- CONTENT ---------------- */
  return (
    <View style={styles.screen}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>
        
        {/* Header & Date Strip */}
        <CalendarHeader onOpenCalendar={() => setCalendarVisible(true)} />
        <DateStrip />

        {/* Progress Section */}
        <ProgressCard 
          taken={2} 
          total={4} 
          percentage={50} 
        />

        {/* Appointments Section */}
        {data.appointments.length > 0 && (
          <View>
            <View style={styles.sectionHeaderRow}>
              <Text style={styles.sectionTitle}>My appointments</Text>
              <Text style={styles.seeAllText}>See all &gt;</Text>
            </View>
            {data.appointments.map((item: any) => (
              <AppointmentCard
                key={item.id}
                doctorName={item.title} 
                specialty={item.subtitle} 
                time="Today, June 25 — 11:00" 
              />
            ))}
          </View>
        )}

        {/* Reminders Section */}
        <View style={styles.sectionHeaderRow}>
          <Text style={styles.sectionTitle}>My reminders</Text>
          <TouchableOpacity style={styles.addButton}>
            <Text style={styles.addButtonText}>+ add</Text>
          </TouchableOpacity>
        </View>

        {/* Morning Subsection */}
        <View style={styles.subSectionHeader}>
          <Text style={{fontSize: 18}}>🌅</Text> 
          <Text style={styles.subSectionTitle}>Morning</Text>
        </View>

        {data.medicines.map((item: any) => (
            <MedicineCard
              key={item.id}
              name={item.title}
              dosage={item.subtitle}
              time="08:00" 
              status={item.status || 'Taken'} 
            />
        ))}

        {data.medicines.length === 0 && data.appointments.length === 0 && (
           <EmptyState
             title="No entries today"
             message="Appointments and medicines will appear here."
           />
        )}
      </ScrollView>

      {/* THE MODAL COMPONENT */}
      <CalendarModal 
        visible={isCalendarVisible} 
        onClose={() => setCalendarVisible(false)}
        selectedDate={selectedDate}
        onSelectDate={setSelectedDate}
        data={data} // Passing data so the modal can show "Today's plan"
      />

    </View>
  );
}