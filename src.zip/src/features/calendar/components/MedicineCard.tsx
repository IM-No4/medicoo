import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { COLORS } from '../styles';

interface Props {
  name: string;
  dosage: string;
  time: string;
  status: 'Taken' | 'Skipped' | 'Pending';
}

export default function MedicineCard({ name, dosage, time, status }: Props) {
  const isTaken = status === 'Taken';
  const isSkipped = status === 'Skipped';

  return (
    <View style={styles.card}>
      {/* Icon */}
      <View style={[styles.iconBox, isSkipped ? styles.iconBoxSkipped : styles.iconBoxDefault]}>
         {/* Placeholder for Pill Icon */}
         <Text style={{fontSize: 20}}>💊</Text>
      </View>

      {/* Info */}
      <View style={styles.info}>
        <Text style={styles.name}>{name}</Text>
        <Text style={styles.dosage}>{dosage}</Text>
      </View>

      {/* Status / Time */}
      <View style={styles.statusContainer}>
        {isTaken && <Text style={styles.statusTaken}>Taken</Text>}
        {isSkipped && <Text style={styles.statusSkipped}>Skipped</Text>}
        <Text style={styles.time}>{time}</Text>
      </View>

      {/* Checkbox */}
      <TouchableOpacity style={[styles.checkbox, isTaken && styles.checkboxChecked, isSkipped && styles.checkboxSkipped]}>
        {isTaken && <Text style={styles.checkIcon}>✓</Text>}
        {isSkipped && <Text style={styles.checkIcon}>✕</Text>}
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 16,
    marginHorizontal: 24,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.03,
    shadowRadius: 5,
    elevation: 1,
  },
  iconBox: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  iconBoxDefault: {
    backgroundColor: '#E0F7F4',
  },
  iconBoxSkipped: {
    backgroundColor: '#FFEBEB',
  },
  info: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.text,
  },
  dosage: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  statusContainer: {
    alignItems: 'flex-end',
    marginRight: 12,
  },
  time: {
    fontSize: 14,
    fontWeight: '700',
    color: COLORS.text,
  },
  statusTaken: {
    fontSize: 12,
    color: COLORS.success,
    marginBottom: 2,
  },
  statusSkipped: {
    fontSize: 12,
    color: COLORS.danger,
    marginBottom: 2,
  },
  checkbox: {
    width: 28,
    height: 28,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#Eef0f5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxChecked: {
    backgroundColor: COLORS.success,
    borderColor: COLORS.success,
  },
  checkboxSkipped: {
    backgroundColor: COLORS.danger,
    borderColor: COLORS.danger,
  },
  checkIcon: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: 'bold',
  }
});