import { StyleSheet, Text, View } from 'react-native';
import { COLORS } from '../styles';

interface Props {
  taken: number;
  total: number;
  percentage: number;
}

export default function ProgressCard({ taken, total, percentage }: Props) {
  return (
    <View style={styles.card}>
      {/* Left: Circular Progress Placeholder */}
      <View style={styles.chartContainer}>
        {/* Simple Ring Visualization using Borders */}
        <View style={styles.ringOuter}>
             <View style={styles.ringInner}>
                <Text style={styles.percentageText}>{percentage}%</Text>
             </View>
        </View>
      </View>

      {/* Right: Text Info */}
      <View style={styles.infoContainer}>
        <Text style={styles.title}>Today's progress</Text>
        <Text style={styles.subtitle}>{taken} of {total} medications taken</Text>
        <Text style={styles.linkText}>See more details &gt;</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 24,
    borderRadius: 24,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 3,
  },
  chartContainer: {
    marginRight: 20,
  },
  // CSS Hack for Ring Chart
  ringOuter: {
    width: 70,
    height: 70,
    borderRadius: 35,
    borderWidth: 6,
    borderColor: COLORS.primary, // The "filled" part (simplified)
    borderLeftColor: '#Eef0f5', // The "empty" part
    borderBottomColor: '#Eef0f5',
    alignItems: 'center',
    justifyContent: 'center',
    transform: [{rotate: '45deg'}]
  },
  ringInner: {
    transform: [{rotate: '-45deg'}] // Counter rotate text
  },
  percentageText: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.text,
  },
  infoContainer: {
    flex: 1,
  },
  title: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 13,
    color: COLORS.textSecondary,
    marginBottom: 8,
  },
  linkText: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.text,
  }
});