import AppIcon from '@/src/components/icons/AppIcon';
import QuantityControl from '@/src/features/pharmacy/components/QuantityControl';
import { RootState } from '@/src/redux/store';
import { useRoute, useNavigation } from '@react-navigation/native';
import { StatusBar } from 'expo-status-bar';
import React, { useMemo } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useSelector } from 'react-redux';
import { CartItem, StoreCart } from '@/src/redux/slices/cart.types';

export default function CartScreen() {
  const route = useRoute<any>();
  const navigation = useNavigation<any>();
  const insets = useSafeAreaInsets();
  const { storeID } = route.params || {};
  
  const carts = useSelector((state: RootState) => state.cart);

  // Get carts to display
  const storeCarts = useMemo(() => {
    if (storeID) {
      // Show specific store cart
      const storeCart = carts[storeID];
      return storeCart ? [storeCart] : [];
    } else {
      // Show all store carts
      return Object.values(carts);
    }
  }, [carts, storeID]);

  const renderStoreCart = ({ item: storeCart }: { item: StoreCart }) => {
    const cartItems = Object.values(storeCart.items);
    const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);
    const totalAmount = cartItems.reduce(
      (sum, item) => sum + ((item.discountPrice || item.price) * item.quantity),
      0
    );

    return (
      <View style={styles.storeCartContainer}>
        {/* Store Header */}
        <View style={styles.storeHeader}>
          <Text style={styles.storeName}>{storeCart.storeName}</Text>
          <Text style={styles.itemCount}>{totalItems} item{totalItems !== 1 ? 's' : ''}</Text>
        </View>

        {/* Cart Items */}
        <FlatList
          data={cartItems}
          keyExtractor={(item) => String(item.sku)}
          renderItem={({ item }) => renderCartItem(item, storeCart.storeId)}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
          scrollEnabled={false}
        />

        {/* Total */}
        <View style={styles.totalContainer}>
          <Text style={styles.totalLabel}>Total</Text>
          <Text style={styles.totalAmount}>₹{totalAmount.toFixed(2)}</Text>
        </View>
      </View>
    );
  };

  const renderCartItem = (item: CartItem, storeId: string) => {
    const itemTotal = (item.discountPrice || item.price) * item.quantity;

    return (
      <View style={styles.cartItem}>
        {item.image ? (
          <Image source={{ uri: item.image }} style={styles.itemImage} />
        ) : (
          <View style={styles.placeholderImage}>
            <AppIcon name="pill" size={32} color="#E5E7EB" />
          </View>
        )}
        
        <View style={styles.itemInfo}>
          <Text style={styles.itemName}>{item.name}</Text>
          {item.brand && (
            <Text style={styles.itemBrand}>{item.brand}</Text>
          )}
          <View style={styles.itemPriceRow}>
            <Text style={styles.itemPrice}>₹{itemTotal.toFixed(2)}</Text>
            {item.discountPrice && item.discountPrice < item.price && (
              <Text style={styles.itemOriginalPrice}>
                ₹{(item.price * item.quantity).toFixed(2)}
              </Text>
            )}
          </View>
        </View>

        <View style={styles.quantityContainer}>
          <QuantityControl
            storeId={storeId}
            sku={item.sku}
            quantity={item.quantity}
            size="medium"
          />
        </View>
      </View>
    );
  };

  if (storeCarts.length === 0) {
    return (
      <View style={[styles.container, styles.emptyContainer]}>
        <StatusBar style="dark" />
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
            <AppIcon name="arrow-left" size={24} color="#1C1C1E" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Cart</Text>
          <View style={styles.backButton} />
        </View>
        
        <View style={styles.emptyContent}>
          <AppIcon name="shopping-cart" size={64} color="#D1D5DB" />
          <Text style={styles.emptyTitle}>Your cart is empty</Text>
          <Text style={styles.emptySubtitle}>
            Add medicines to get started
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 16 }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <AppIcon name="arrow-left" size={24} color="#1C1C1E" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Cart</Text>
        <View style={styles.backButton} />
      </View>

      {/* Cart List */}
      <FlatList
        data={storeCarts}
        keyExtractor={(item) => item.storeId}
        renderItem={renderStoreCart}
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 100 }]}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={() => <View style={styles.storeSeparator} />}
      />

      {/* Checkout Button */}
      <View style={[styles.checkoutContainer, { paddingBottom: insets.bottom + 16 }]}>
        <TouchableOpacity style={styles.checkoutButton} activeOpacity={0.8}>
          <Text style={styles.checkoutText}>Proceed to Checkout</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F6F7F9',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1C1C1E',
  },
  content: {
    padding: 16,
  },
  storeCartContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
  },
  storeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  storeName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1C1C1E',
  },
  itemCount: {
    fontSize: 14,
    fontWeight: '500',
    color: '#6B7280',
  },
  cartItem: {
    flexDirection: 'row',
    paddingVertical: 12,
  },
  itemImage: {
    width: 80,
    height: 80,
    borderRadius: 12,
    backgroundColor: '#F3F4F6',
    marginRight: 12,
  },
  placeholderImage: {
    width: 80,
    height: 80,
    borderRadius: 12,
    backgroundColor: '#F3F4F6',
    marginRight: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  itemInfo: {
    flex: 1,
    justifyContent: 'center',
    gap: 4,
  },
  itemName: {
    fontSize: 15,
    fontWeight: '600',
    color: '#1C1C1E',
  },
  itemBrand: {
    fontSize: 13,
    fontWeight: '400',
    color: '#6B7280',
  },
  itemPriceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 4,
  },
  itemPrice: {
    fontSize: 16,
    fontWeight: '700',
    color: '#0E7439',
  },
  itemOriginalPrice: {
    fontSize: 13,
    fontWeight: '400',
    color: '#9CA3AF',
    textDecorationLine: 'line-through',
  },
  quantityContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  separator: {
    height: 1,
    backgroundColor: '#E5E7EB',
    marginLeft: 92,
  },
  storeSeparator: {
    height: 16,
  },
  totalContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
  totalLabel: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1C1C1E',
  },
  totalAmount: {
    fontSize: 20,
    fontWeight: '700',
    color: '#0E7439',
  },
  checkoutContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  checkoutButton: {
    backgroundColor: '#0E7439',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkoutText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  emptyContainer: {
    justifyContent: 'center',
  },
  emptyContent: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1C1C1E',
    marginTop: 24,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    fontWeight: '400',
    color: '#6B7280',
    textAlign: 'center',
  },
});
