import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AppIcon from '../../components/icons/AppIcon';

import { DoctorStackParamList } from '@/src/navigation/DoctorStack';

export default function BookAppointmentScreen() {
    type NavigationProp = NativeStackNavigationProp<
    DoctorStackParamList,
    'BookAppointment'
    >;

    type RouteProps = RouteProp<
    DoctorStackParamList,
    'BookAppointment'
    >;

    const navigation = useNavigation<NavigationProp>();
    const route = useRoute<RouteProps>();
    const insets = useSafeAreaInsets();
    const { doctor } = route.params || {};

    const [selectedDate, setSelectedDate] = useState(0); // Index of selected date
    const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
    const [slots, setSlots] = useState<any>(null);
    const [loading, setLoading] = useState(true);

  // Generate next 7 days
  const dates = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    return {
      day: d.toLocaleDateString('en-US', { weekday: 'short' }),
      date: d.getDate(),
      fullDate: d.toISOString().split('T')[0],
    };
  });

  useEffect(() => {
    loadSlots();
  }, [selectedDate]);

  const loadSlots = async () => {
    setLoading(true);
    try {
      const result = {
        morning: [],
        afternoon: [],
        evening: [],
    };
      setSlots(result);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleConfirm = () => {
    if (!selectedSlot) return;
    // Navigate to success or home
    navigation.navigate('BookingSuccess');
  };

  if (!doctor) return null;

  return (
    <View style={styles.screen}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />
      
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 10 }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.iconButton}>
          <AppIcon name="arrow-left" size={24} color="#1c1c1e" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Select Time</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        
        {/* Doctor Summary */}
        <View style={styles.doctorSummary}>
          <View style={styles.imageContainer}>
            <Text style={{ fontSize: 24 }}>{doctor.image}</Text>
          </View>
          <View>
            <Text style={styles.docName}>{doctor.name}</Text>
            <Text style={styles.docSpecialty}>{doctor.specialty}</Text>
          </View>
        </View>

        {/* Date Picker */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Day</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {dates.map((item, index) => {
              const isSelected = selectedDate === index;
              return (
                <TouchableOpacity
                  key={index}
                  style={[styles.dateCard, isSelected && styles.dateCardSelected]}
                  onPress={() => {
                    setSelectedDate(index);
                    setSelectedSlot(null);
                  }}
                >
                  <Text style={[styles.dayText, isSelected && styles.textSelected]}>{item.day}</Text>
                  <Text style={[styles.dateText, isSelected && styles.textSelected]}>{item.date}</Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        </View>

        {/* Time Slots */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Time</Text>
          
          {loading ? (
            <ActivityIndicator color="#1C6ED5" style={{ marginTop: 20 }} />
          ) : (
            <>
              {/* Morning */}
              <Text style={styles.slotHeader}>Morning</Text>
              <View style={styles.slotGrid}>
                {slots?.morning.map((time: string) => (
                  <TouchableOpacity
                    key={time}
                    style={[styles.slotChip, selectedSlot === time && styles.slotChipSelected]}
                    onPress={() => setSelectedSlot(time)}
                  >
                    <Text style={[styles.slotText, selectedSlot === time && styles.slotTextSelected]}>
                      {time}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Afternoon */}
              <Text style={styles.slotHeader}>Afternoon</Text>
              <View style={styles.slotGrid}>
                {slots?.afternoon.map((time: string) => (
                  <TouchableOpacity
                    key={time}
                    style={[styles.slotChip, selectedSlot === time && styles.slotChipSelected]}
                    onPress={() => setSelectedSlot(time)}
                  >
                    <Text style={[styles.slotText, selectedSlot === time && styles.slotTextSelected]}>
                      {time}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Evening */}
              <Text style={styles.slotHeader}>Evening</Text>
              <View style={styles.slotGrid}>
                {slots?.evening.map((time: string) => (
                  <TouchableOpacity
                    key={time}
                    style={[styles.slotChip, selectedSlot === time && styles.slotChipSelected]}
                    onPress={() => setSelectedSlot(time)}
                  >
                    <Text style={[styles.slotText, selectedSlot === time && styles.slotTextSelected]}>
                      {time}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </>
          )}
        </View>

      </ScrollView>

      {/* Bottom Bar */}
      <View style={[styles.bottomBar, { paddingBottom: insets.bottom + 16 }]}>
        <TouchableOpacity 
          style={[styles.confirmButton, !selectedSlot && styles.disabledButton]} 
          disabled={!selectedSlot}
          onPress={handleConfirm}
        >
          <Text style={styles.confirmButtonText}>Confirm Appointment</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#F2F2F7',
  },
  iconButton: { padding: 4 },
  headerTitle: { fontSize: 18, fontWeight: '600', color: '#1c1c1e' },
  scrollContent: { paddingBottom: 140 },
  doctorSummary: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#F2F2F7',
  },
  imageContainer: {
    width: 56, height: 56, borderRadius: 28, backgroundColor: '#F2F2F7',
    justifyContent: 'center', alignItems: 'center', marginRight: 16,
  },
  docName: { fontSize: 16, fontWeight: '600', color: '#1c1c1e', marginBottom: 2 },
  docSpecialty: { fontSize: 14, color: '#8e8e93' },
  section: { padding: 20, paddingBottom: 0 },
  sectionTitle: { fontSize: 16, fontWeight: '600', color: '#1c1c1e', marginBottom: 12 },
  dateCard: {
    width: 60, height: 70, borderRadius: 12, borderWidth: 1, borderColor: '#E5E5EA',
    justifyContent: 'center', alignItems: 'center', marginRight: 12, backgroundColor: '#fff',
  },
  dateCardSelected: { backgroundColor: '#1C6ED5', borderColor: '#1C6ED5' },
  dayText: { fontSize: 12, color: '#8e8e93', marginBottom: 4 },
  dateText: { fontSize: 16, fontWeight: '600', color: '#1c1c1e' },
  textSelected: { color: '#fff' },
  slotHeader: { fontSize: 14, fontWeight: '500', color: '#8e8e93', marginTop: 16, marginBottom: 12 },
  slotGrid: { flexDirection: 'row', flexWrap: 'wrap' },
  slotChip: {
    paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20, borderWidth: 1, borderColor: '#E5E5EA',
    marginRight: 10, marginBottom: 10, backgroundColor: '#fff',
  },
  slotChipSelected: { backgroundColor: '#1C6ED5', borderColor: '#1C6ED5' },
  slotText: { fontSize: 14, color: '#1c1c1e' },
  slotTextSelected: { color: '#fff', fontWeight: '600' },
  bottomBar: {
    position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: '#fff',
    padding: 20, paddingBottom: 32, borderTopWidth: 1, borderTopColor: '#E5E5EA',
  },
  confirmButton: {
    backgroundColor: '#1C6ED5', borderRadius: 24, paddingVertical: 16, alignItems: 'center',
  },
  disabledButton: { backgroundColor: '#A0C4F2' },
  confirmButtonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});