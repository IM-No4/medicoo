import { DoctorStackParamList } from '@/src/navigation/DoctorStack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import React, { useEffect, useRef, useState } from 'react';
import { ScrollView, Share, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AppIcon from '../../components/icons/AppIcon';

export default function DoctorDetailsScreen() {
  type NavProp = NativeStackNavigationProp<
    DoctorStackParamList,
    'DoctorDetail'
  >;

  const navigation = useNavigation<NavProp>();
  type RouteProps = RouteProp<
    DoctorStackParamList,
    'DoctorDetail'
  >;

  const route = useRoute<RouteProps>();
  const { doctor, doctorId, intent } = route.params || {};
  const insets = useSafeAreaInsets();
  const [isFavorite, setIsFavorite] = useState(false);
  const hasAutoBookedRef = useRef(false);

  useEffect(() => {
    checkFavoriteStatus();
  }, []);

  useEffect(() => {
    if (
      intent === 'BOOK' &&
      doctor &&
      !hasAutoBookedRef.current
    ) {
      hasAutoBookedRef.current = true;
      navigation.navigate('BookAppointment', { doctor });
    }
  }, [intent, doctor, navigation]);

  const checkFavoriteStatus = async () => {
    try {
      const stored = await AsyncStorage.getItem('favorites');
      if (stored) {
        const favorites = JSON.parse(stored);
        if (favorites.includes(doctor.id)) setIsFavorite(true);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const toggleFavorite = async () => {
    try {
      const stored = await AsyncStorage.getItem('favorites');
      let favorites = stored ? JSON.parse(stored) : [];
      
      if (isFavorite) {
        favorites = favorites.filter((id: string) => id !== doctor.id);
      } else {
        favorites.push(doctor.id);
      }
      
      await AsyncStorage.setItem('favorites', JSON.stringify(favorites));
      setIsFavorite(!isFavorite);
    } catch (e) {
      console.error(e);
    }
  };

  const handleShare = async () => {
    try {
      const url = `medicoo://doctor/${doctor.id}`;
      await Share.share({
        message: `Check out Dr. ${doctor.name}, ${doctor.specialty} at ${doctor.location}. Book here: ${url}`,
        url: url, // iOS support
      });
    } catch (e) {
      console.error(e);
    }
  };

  if (!doctor) return null;

  return (
    <View style={styles.screen}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />
      
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 10 }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.iconButton}>
          <AppIcon name="arrow-left" size={24} color="#1c1c1e" />
        </TouchableOpacity>
        <View style={styles.headerActions}>
          <TouchableOpacity onPress={toggleFavorite} style={styles.iconButton}>
            <AppIcon name="heart" size={24} color={isFavorite ? "#FF3B30" : "#1c1c1e"} />
          </TouchableOpacity>
          <TouchableOpacity onPress={handleShare} style={[styles.iconButton, { marginLeft: 8 }]}>
            <AppIcon name="share" size={24} color="#1c1c1e" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        
        {/* Profile Section */}
        <View style={styles.profileSection}>
          <View style={styles.imageContainer}>
            <Text style={{ fontSize: 48 }}>{doctor.image}</Text>
            <View style={styles.verifiedBadge}>
              <AppIcon name="check-circle" size={16} color="#fff" />
            </View>
          </View>
          
          <Text style={styles.name}>{doctor.name}</Text>
          <Text style={styles.specialty}>{doctor.specialty}</Text>
          
          <View style={styles.locationTag}>
            <AppIcon name="map-pin" size={12} color="#1C6ED5" />
            <Text style={styles.locationText}>{doctor.location}</Text>
          </View>
        </View>

        {/* Stats Row */}
        <View style={styles.statsRow}>
          <View style={styles.statItem}>
            <View style={[styles.statIcon, { backgroundColor: '#EAF4FF' }]}>
              <AppIcon name="users" size={20} color="#1C6ED5" />
            </View>
            <Text style={styles.statValue}>5000+</Text>
            <Text style={styles.statLabel}>Patients</Text>
          </View>
          
          <View style={styles.statItem}>
            <View style={[styles.statIcon, { backgroundColor: '#FFF6EA' }]}>
              <AppIcon name="star" size={20} color="#C47A16" />
            </View>
            <Text style={styles.statValue}>{doctor.rating}</Text>
            <Text style={styles.statLabel}>{doctor.reviews} Reviews</Text>
          </View>

          <View style={styles.statItem}>
            <View style={[styles.statIcon, { backgroundColor: '#EAFBF3' }]}>
              <AppIcon name="stethoscope" size={20} color="#0E7439" />
            </View>
            <Text style={styles.statValue}>{doctor.experience}</Text>
            <Text style={styles.statLabel}>Experience</Text>
          </View>
        </View>

        {/* About Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About Doctor</Text>
          <Text style={styles.aboutText}>
            {doctor.name} is a highly skilled {doctor.specialty} with over {doctor.experience} of experience in treating patients with complex medical conditions. Dedicated to providing compassionate care and personalized treatment plans.
          </Text>
        </View>

        {/* Availability */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Availability</Text>
          <View style={styles.availabilityCard}>
            <View style={styles.availabilityRow}>
              <AppIcon name="calendar-days" size={20} color="#5B4FDB" />
              <Text style={styles.availabilityText}>Next Available: {doctor.nextSlot}</Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.availabilityRow}>
              <AppIcon name="clock" size={20} color="#5B4FDB" />
              <Text style={styles.availabilityText}>10:00 AM - 07:00 PM</Text>
            </View>
          </View>
        </View>

      </ScrollView>

      {/* Bottom Action Bar */}
      <View style={[styles.bottomBar, { paddingBottom: insets.bottom + 16 }]}>
        <View style={styles.priceContainer}>
          <Text style={styles.priceLabel}>Consultation Fee</Text>
          <Text style={styles.priceValue}>$40.00</Text>
        </View>
        <TouchableOpacity
          style={styles.bookButton}
          onPress={() => navigation.navigate('BookAppointment', { doctor })}
        >
          <Text style={styles.bookButtonText}>Book Appointment</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#F2F2F7',
  },
  headerTitleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1c1c1e',
  },
  scrollContent: {
    paddingBottom: 140,
  },
  profileSection: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  imageContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#F2F2F7',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    position: 'relative',
  },
  verifiedBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: '#2FA561',
    borderRadius: 12,
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#fff',
  },
  name: {
    fontSize: 22,
    fontWeight: '700',
    color: '#1c1c1e',
    marginBottom: 4,
  },
  specialty: {
    fontSize: 15,
    color: '#8e8e93',
    marginBottom: 12,
  },
  locationTag: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EAF4FF',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  locationText: {
    fontSize: 13,
    color: '#1C6ED5',
    fontWeight: '600',
    marginLeft: 4,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 24,
    borderBottomWidth: 8,
    borderBottomColor: '#F2F2F7',
  },
  statItem: {
    alignItems: 'center',
  },
  statIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  statValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1c1c1e',
  },
  statLabel: {
    fontSize: 12,
    color: '#8e8e93',
  },
  section: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#F2F2F7',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1c1c1e',
    marginBottom: 12,
  },
  aboutText: {
    fontSize: 15,
    color: '#3A3A3C',
    lineHeight: 22,
  },
  availabilityCard: {
    backgroundColor: '#F1EEFF',
    borderRadius: 16,
    padding: 16,
  },
  availabilityRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  availabilityText: {
    fontSize: 15,
    color: '#5B4FDB',
    fontWeight: '500',
    marginLeft: 12,
  },
  divider: {
    height: 1,
    backgroundColor: '#D6D1F5',
    marginVertical: 12,
  },
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#fff',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#E5E5EA',
  },
  priceContainer: {
    flex: 1,
  },
  priceLabel: {
    fontSize: 12,
    color: '#8e8e93',
  },
  priceValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1c1c1e',
  },
  bookButton: {
    backgroundColor: '#1C6ED5',
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 24,
  },
  bookButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});