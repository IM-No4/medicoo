import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Modal,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import AppIcon from '../../components/icons/AppIcon';
import DoctorCard from './components/DoctorCard';

type Doctor = {
  id: string;
  name: string;
  specialty: string;
  experience: number;
  rating: number;
};

const MOCK_DOCTORS: Doctor[] = [
  { id: 'd1', name: 'Dr. Anil Sharma', specialty: 'Dermatologist', experience: 12, rating: 4.6 },
  { id: 'd2', name: 'Dr. Meera Iyer', specialty: 'General Physician', experience: 8, rating: 4.4 },
];

const majorSpecializations = [
  { id: 'Cardiologist', label: 'Cardiologist', icon: 'heart', color: '#FF6F61' },
  { id: 'Dermatologist', label: 'Dermatologist', icon: 'sun', color: '#6B5B95' },
  { id: 'General Practitioner', label: 'General Practitioner', icon: 'profile', color: '#88B04B' },
  { id: 'Pediatrician', label: 'Pediatrician', icon: 'baby', color: '#F7CAC9' },
  { id: 'Orthopedic Surgeon', label: 'Orthopedic Surgeon', icon: 'bone', color: '#92A8D1' },
  { id: 'Neurologist', label: 'Neurologist', icon: 'brain', color: '#FFC107' },
  { id: 'Gastroenterologist', label: 'Gastroenterologist', icon: 'apple', color: '#8E44AD' },
  { id: 'Pulmonologist', label: 'Pulmonologist', icon: 'wind', color: '#27AE60' },
  { id: 'Urologist', label: 'Urologist', icon: 'droplet', color: '#3498DB' },
  { id: 'Endocrinologist', label: 'Endocrinologist', icon: 'flask-conical', color: '#2ECC71' },
  { id: 'Psychiatrist', label: 'Psychiatrist', icon: 'brain-circuit', color: '#9B59B6' },
  { id: 'Rheumatologist', label: 'Rheumatologist', icon: 'flower-2', color: '#E67E22' },
  { id: 'Ophthalmologist', label: 'Ophthalmologist', icon: 'eye', color: '#2980B9' },
  { id: 'Oncologist', label: 'Oncologist', icon: 'briefcase-medical', color: '#C0392B' },
  { id: 'Dentist', label: 'Dentist', icon: 'smile', color: '#2E86C1' },
];

export default function DoctorListScreen() {
  const navigation = useNavigation<any>();
  const insets = useSafeAreaInsets();

  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('All');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);

  const [filterModalVisible, setFilterModalVisible] = useState(false);
  const [sortModalVisible, setSortModalVisible] = useState(false);
  const [sortBy, setSortBy] =
    useState<'rating_low' | 'rating_high' | 'experience_low' | 'experience_high'>('rating_high');

  // ---------------- Load Doctors ----------------
  useEffect(() => {
    setDoctors(
      MOCK_DOCTORS.map(d => ({
        ...d,
        consultationFee: Math.floor(Math.random() * 800) + 300,
      }))
    );
    setLoading(false);
    loadFavorites();
  }, []);

  // ---------------- Favorites ----------------
  const loadFavorites = async () => {
    try {
      const stored = await AsyncStorage.getItem('favorites');
      if (stored) setFavorites(JSON.parse(stored));
    } catch {}
  };

  const toggleFavorite = async (id: string) => {
    const updated = favorites.includes(id)
      ? favorites.filter(f => f !== id)
      : [...favorites, id];

    setFavorites(updated);
    await AsyncStorage.setItem('favorites', JSON.stringify(updated));
  };

  // ---------------- Sorting Label ----------------
  const getSortLabel = () => {
    switch (sortBy) {
      case 'rating_low': return 'Rating: Low to High';
      case 'rating_high': return 'Rating: High to Low';
      case 'experience_low': return 'Experience: Low to High';
      case 'experience_high': return 'Experience: High to Low';
      default: return 'Sort';
    }
  };

  // ---------------- Filtering + Sorting Logic ----------------
  const filteredDoctors = doctors
    .filter(doc => {
      const q = searchQuery.toLowerCase();
      const matchesSearch =
        doc.name.toLowerCase().includes(q) ||
        doc.specialty.toLowerCase().includes(q);

      const matchesSpecialty =
        selectedSpecialty === 'All' || doc.specialty === selectedSpecialty;

      const matchesFavorite =
        !showFavoritesOnly || favorites.includes(doc.id);

      return matchesSearch && matchesSpecialty && matchesFavorite;
    })
    .sort((a, b) => {
      if (sortBy === 'rating_low') return a.rating - b.rating;
      if (sortBy === 'rating_high') return b.rating - a.rating;
      if (sortBy === 'experience_low') return a.experience - b.experience;
      if (sortBy === 'experience_high') return b.experience - a.experience;
      return 0;
    });

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#1C6ED5" />
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />

      {/* ---------- Header ---------- */}
      <View style={styles.header}>
        <View style={styles.topRow}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
            <AppIcon name="arrow-left" size={24} color="#1c1c1e" />
          </TouchableOpacity>

          <Text style={styles.title}>Consult a Doctor</Text>

          <View style={{ width: 24 }} />
        </View>

        {/* ---------- Search Box ---------- */}
        <View style={styles.searchBox}>
          <AppIcon name="search" size={20} color="#8e8e93" />
          <TextInput
            placeholder="Search doctors, specialties..."
            placeholderTextColor="#8e8e93"
            style={styles.input}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          {searchQuery !== '' && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <AppIcon name="x" size={18} color="#8e8e93" />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* ---------- Filter Chips ---------- */}
      <View style={styles.filterBar}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterRow}>
          <TouchableOpacity style={styles.filterButton} onPress={() => setFilterModalVisible(true)}>
            <AppIcon name="filter" size={16} color="#1c1c1e" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.sortButton} onPress={() => setSortModalVisible(true)}>
            <Text style={styles.sortButtonText}>{getSortLabel()}</Text>
            <AppIcon name="chevron-down" size={14} color="#1c1c1e" />
          </TouchableOpacity>
          <View style={styles.verticalDivider} />

          <TouchableOpacity
            style={[styles.chip, showFavoritesOnly && styles.chipSelected]}
            onPress={() => setShowFavoritesOnly(!showFavoritesOnly)}
          >
            <Text style={[styles.chipText, showFavoritesOnly && styles.chipTextSelected]}>
              Favorites
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.chip, selectedSpecialty === 'All' && styles.chipSelected]}
            onPress={() => setSelectedSpecialty('All')}
          >
            <Text style={[styles.chipText, selectedSpecialty === 'All' && styles.chipTextSelected]}>
              All
            </Text>
          </TouchableOpacity>

          {majorSpecializations.map(spec => (
            <TouchableOpacity
              key={spec.id}
              style={[styles.chip, selectedSpecialty === spec.id && styles.chipSelected]}
              onPress={() => setSelectedSpecialty(spec.id)}
            >
              <Text style={[styles.chipText, selectedSpecialty === spec.id && styles.chipTextSelected]}>
                {spec.label}
              </Text>
            </TouchableOpacity>
          ))}

        </ScrollView>
      </View>

      {/* ---------- Doctor List ---------- */}
      <ScrollView contentContainerStyle={styles.listContent} showsVerticalScrollIndicator={false}>
        {filteredDoctors.map(doc => (
          <DoctorCard
            key={doc.id}
            doctor={doc}
            isFavorite={favorites.includes(doc.id)}
            onToggleFavorite={() => toggleFavorite(doc.id)}
            onBook={() => navigation.navigate('BookAppointment', { doc })}
            onPress={() => navigation.navigate('DoctorDetail', { doc })}
          />
        ))}

        {filteredDoctors.length === 0 && (
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>No doctors match your filters.</Text>
          </View>
        )}
      </ScrollView>

      {/* Filter Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={filterModalVisible}
        onRequestClose={() => setFilterModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <TouchableWithoutFeedback onPress={() => setFilterModalVisible(false)}>
            <View style={styles.modalBackdrop} />
          </TouchableWithoutFeedback>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Filter by Specialty</Text>
              <TouchableOpacity onPress={() => setFilterModalVisible(false)}>
                <AppIcon name="x" size={24} color="#1c1c1e" />
              </TouchableOpacity>
            </View>

            <ScrollView
              showsVerticalScrollIndicator={false}
              contentContainerStyle={{ paddingBottom: 0 }}
            >
              <Text style={styles.sectionHeader}>Specialty</Text>

              <View style={styles.specialtyGrid}>
                {majorSpecializations.map((spec) => (
                  <TouchableOpacity
                    key={spec.id}
                    style={[
                      styles.gridItem,
                      selectedSpecialty === spec.id && styles.gridItemSelected,
                    ]}
                    onPress={() => setSelectedSpecialty(spec.id)}
                  >
                    <AppIcon
                      name={spec.icon}
                      size={24}
                      color={selectedSpecialty === spec.id ? '#fff' : spec.color}
                    />
                    <Text
                      style={[
                        styles.gridLabel,
                        selectedSpecialty === spec.id && styles.gridLabelSelected,
                      ]}
                    >
                      {spec.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>

            {/* Sticky footer */}
            <View style={[styles.modalFooter, { paddingBottom: insets.bottom + 16 }]}>
              <TouchableOpacity
                style={styles.applyButton}
                onPress={() => setFilterModalVisible(false)}
              >
                <Text style={styles.applyButtonText}>Apply Filters</Text>
              </TouchableOpacity>
            </View>
          </View>

        </View>
      </Modal>

      {/* ---------- Sort Modal ---------- */}
      <Modal visible={sortModalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <TouchableWithoutFeedback onPress={() => setSortModalVisible(false)}>
            <View style={styles.modalBackdrop} />
          </TouchableWithoutFeedback>

          <View style={[styles.modalContent, { paddingBottom: insets.bottom }]}>
            <Text style={styles.modalTitle}>Sort By</Text>

            {[
              { id: 'rating_high', label: 'Rating: High to Low' },
              { id: 'rating_low', label: 'Rating: Low to High' },
              { id: 'experience_high', label: 'Experience: High to Low' },
              { id: 'experience_low', label: 'Experience: Low to High' },
            ].map(opt => (
              <TouchableOpacity
                key={opt.id}
                style={[styles.sortOption, sortBy === opt.id && styles.sortOptionSelected]}
                onPress={() => {
                  setSortBy(opt.id as any);
                  setSortModalVisible(false);
                }}
              >
                <Text style={[styles.sortOptionText, sortBy === opt.id && styles.sortOptionTextSelected]}>
                  {opt.label}
                </Text>
                {sortBy === opt.id && <AppIcon name="check" size={20} color="#1C6ED5" />}
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </Modal>
    </View>
  );
}

// ---------------- STYLES ----------------

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#F2F2F7' },

  loadingContainer: { flex: 1, alignItems: 'center', justifyContent: 'center' },

  header: {
    backgroundColor: '#fff',
    paddingTop: 50,
    paddingBottom: 16,
    paddingHorizontal: 20,
  },

  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },

  backButton: { padding: 4 },

  title: { fontSize: 18, fontWeight: '600', color: '#1c1c1e' },

  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F2F2F7',
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 44,
  },

  input: { flex: 1, marginLeft: 8, fontSize: 15, color: '#1c1c1e' },

  filterBar: {
    backgroundColor: '#fff',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5EA',
  },

  filterRow: { paddingHorizontal: 16, alignItems: 'center' },

  sortChip: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E5E5EA',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginRight: 10,
  },

  sortChipText: { fontSize: 13, color: '#1c1c1e', marginRight: 6, fontWeight: '500' },

  filterButton: {
    padding: 8,
    backgroundColor: '#F2F2F7',
    borderRadius: 8,
    marginRight: 12,
  },
  sortButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#E5E5EA',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginRight: 12,
  },
  sortButtonText: {
    fontSize: 13,
    color: '#1c1c1e',
    fontWeight: '500',
    marginRight: 4,
  },
  verticalDivider: {
    width: 1,
    height: 24,
    backgroundColor: '#E5E5EA',
    marginRight: 12,
  },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E5E5EA',
    backgroundColor: '#fff',
    marginRight: 8,
  },

  chipSelected: { backgroundColor: '#1C6ED5', borderColor: '#1C6ED5' },

  chipText: { fontSize: 13, color: '#1c1c1e', fontWeight: '500' },

  chipTextSelected: { color: '#fff' },

  listContent: { padding: 20, paddingBottom: 40 },

  emptyState: { padding: 40, alignItems: 'center' },

  emptyText: { color: '#8e8e93', fontSize: 15 },

  modalOverlay: { flex: 1, justifyContent: 'flex-end' },

  modalBackdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.4)' },

  modalContent: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 18,
  },

  modalTitle: { fontSize: 18, fontWeight: '700', marginBottom: 16 },

  sortOption: {
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#F2F2F7',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },

  sortOptionSelected: { backgroundColor: '#F2F8FF' },

  sortOptionText: { fontSize: 16, color: '#1c1c1e' },

  sortOptionTextSelected: { color: '#1C6ED5', fontWeight: '600' },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  sectionHeader: { fontSize: 16, fontWeight: '600', color: '#1c1c1e', marginBottom: 12, marginTop: 8 },
  specialtyGrid: { flexDirection: 'row', justifyContent: 'space-between',flexWrap: 'wrap', marginBottom: 0},
  gridItem: {
    width: '32%', aspectRatio: 1, backgroundColor: '#F2F2F7', borderRadius: 16,
    justifyContent: 'center', alignItems: 'center', marginBottom: 12,
  },
  gridItemSelected: { backgroundColor: '#1C6ED5' },
  gridLabel: {
    fontSize: 11, color: '#1c1c1e', marginTop: 8, textAlign: 'center', fontWeight: '500',
  },
  gridLabelSelected: { color: '#fff' },
  applyButton: {
    backgroundColor: '#1C6ED5', paddingVertical: 16, borderRadius: 16, alignItems: 'center',
  },
  applyButtonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  modalFooter: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 16,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#E5E5EA',
  },
});
