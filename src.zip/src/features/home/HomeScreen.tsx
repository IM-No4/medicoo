import { useBottomTabBarHeight } from '@react-navigation/bottom-tabs';
import { useFocusEffect } from '@react-navigation/native';
import { StatusBar } from 'expo-status-bar';
import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { Animated, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useDispatch, useSelector } from 'react-redux';

import HealthSummary from './components/HealthSummary';
import HomeFeedContainer from './components/HomeFeedContainer';
import HomeHeader from './components/HomeHeader';
import QuickActions from './components/QuickActions';
import ServicesSection from './components/ServicesSection';
import UpcomingSection from './components/UpcomingSection';

import HealthSummarySkeleton from './skeletons/HealthSummarySkeleton';
import QuickActionsSkeleton from './skeletons/QuickActionsSkeleton';
import ServicesSkeleton from './skeletons/ServicesSkeleton';
import UpcomingSkeleton from './skeletons/UpcomingSkeleton';

import { useNavigation } from '@react-navigation/native';
import { setHomeBootstrapped } from '../../redux/slices/appSlice';
import { RootState } from '../../redux/store';


const HEADER_MAX_HEIGHT = 160;
const FADE_DURATION = 180;

type Props = {
  onOpenCommandPalette: () => void;
};

const QUICK_ACTIONS = [
  {
    id: 'doctor',
    title: 'Doctor',
    icon: 'stethoscope',
    actionKey: 'BOOK_DOCTOR',
    background: { start: '#ffffffff', end: '#ffffffff' },
    accentColor: '#0284C7',
  },
  {
    id: 'medicines',
    title: 'Medicines',
    icon: 'pill',
    actionKey: 'ORDER_MEDICINES',
    background: { start: '#ffffffff', end: '#ffffffff' },
    accentColor: '#15803D',
  },
  {
    id: 'upload',
    title: 'Upload Rx',
    icon: 'notepad-text',
    actionKey: 'UPLOAD_RX',
    background: { start: '#ffffffff', end: '#ffffffff' },
    accentColor: '#B45309',
  },
  {
    id: 'lab',
    title: 'Lab Tests',
    icon: 'flask',
    actionKey: 'LAB_TESTS',
    background: { start: '#ffffffff', end: '#ffffffff' },
    accentColor: '#7C3AED',
  },
];

export default function HomeScreen({ onOpenCommandPalette }: Props) {
  const navigation = useNavigation<any>();
  const [uploadVisible, setUploadVisible] = useState(false);

  const scrollY = useRef(new Animated.Value(0)).current;
  const contentFade = useRef(new Animated.Value(0)).current;

  const tabBarHeight = useBottomTabBarHeight();
  const insets = useSafeAreaInsets();
  const dispatch = useDispatch();

  const HEADER_HEIGHT = HEADER_MAX_HEIGHT + insets.top;

  const [darkStatusBar, setDarkStatusBar] = useState(false);
  const lastStatusRef = useRef(false);

  const homeBootstrapped = useSelector(
    (state: RootState) => state.app.homeBootstrapped
  );

  const loading = !homeBootstrapped;

  const feedPlaceholder = useMemo(() => [{ id: 'feed' }], []);

  useFocusEffect(
    useCallback(() => {
      setDarkStatusBar(false);
      lastStatusRef.current = false;
    }, [])
  );

  const handleQuickAction = useCallback(
    (actionKey: string) => {
      switch (actionKey) {
        case 'BOOK_DOCTOR':
          navigation.navigate('DoctorStack');
          break;

        case 'ORDER_MEDICINES':
          navigation.navigate('PharmacyStack');
          break;

        case 'UPLOAD_RX':
          setUploadVisible(true);
          break;

        case 'LAB_TESTS':
          navigation.navigate('LabStack');
          break;

        default:
          break;
      }
    },
    [navigation]
  );

  useEffect(() => {
    const id = scrollY.addListener(({ value }) => {
      const shouldBeDark = value > HEADER_MAX_HEIGHT;

      if (lastStatusRef.current !== shouldBeDark) {
        lastStatusRef.current = shouldBeDark;
        setDarkStatusBar(shouldBeDark);
      }
    });

    return () => scrollY.removeListener(id);
  }, [scrollY]);

  useEffect(() => {
    if (!homeBootstrapped) {
      const timer = setTimeout(() => {
        dispatch(setHomeBootstrapped());

        Animated.timing(contentFade, {
          toValue: 1,
          duration: FADE_DURATION,
          useNativeDriver: true,
        }).start();
      }, 500);

      return () => clearTimeout(timer);
    } else {
      contentFade.setValue(1);
    }
  }, [homeBootstrapped, dispatch, contentFade]);

  const ListHeader = useMemo(
    () => (
      <View>
        {loading ? (
          <>
            <QuickActionsSkeleton />
            <ServicesSkeleton />
            <UpcomingSkeleton />
            <HealthSummarySkeleton />
          </>
        ) : (
          <Animated.View style={{ opacity: contentFade }}>
            <QuickActions
              items={QUICK_ACTIONS}
              onActionPress={handleQuickAction}
            />
            <ServicesSection />
            <UpcomingSection />
            <HealthSummary />
          </Animated.View>
        )}
      </View>
    ),
    [loading, contentFade]
  );

  return (
    <View style={{ flex: 1, backgroundColor: '#ffffff' }}>
      <StatusBar
        translucent
        style={darkStatusBar ? 'dark' : 'light'}
        backgroundColor={darkStatusBar ? '#ffffff' : 'transparent'}
      />

      {darkStatusBar && (
        <View
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: insets.top,
            backgroundColor: '#ffffff',
            zIndex: 20,
          }}
        />
      )}

      <HomeHeader
        scrollY={scrollY}
        maxHeight={HEADER_MAX_HEIGHT}
        onOpenCommandPalette={onOpenCommandPalette}
      />

      <Animated.FlatList
        data={feedPlaceholder}
        keyExtractor={(item) => item.id}
        renderItem={() => <HomeFeedContainer />}
        ListHeaderComponent={ListHeader}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingTop: HEADER_HEIGHT,
          paddingBottom: tabBarHeight + 16,
        }}
        scrollEventThrottle={8}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
      />
    </View>
  );
}
