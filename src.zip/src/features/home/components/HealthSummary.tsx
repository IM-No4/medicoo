import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

function HealthSummary() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Health Summary</Text>
      <View style={styles.row}>
        <View style={styles.box}>
          <Text style={styles.value}>72</Text>
          <Text style={styles.label}>Weight</Text>
        </View>
        <View style={styles.box}>
          <Text style={styles.value}>118/76</Text>
          <Text style={styles.label}>BP</Text>
        </View>
      </View>
    </View>
  );
}

export default React.memo(HealthSummary);

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 16,
    marginBottom: 24,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  box: {
    flex: 1,
    padding: 14,
    borderRadius: 14,
    backgroundColor: '#F1F5F9',
  },
  value: {
    fontSize: 18,
    fontWeight: '700',
  },
  label: {
    fontSize: 12,
    opacity: 0.6,
    marginTop: 4,
  },
});
