import React, { useEffect, useRef, useState } from 'react';
import { Animated, FlatList } from 'react-native';

import { HomeFeedItem } from '../feed/feed.types';
import HomeFeedRenderer from '../feed/HomeFeedRenderer';
import HomeFeedSkeleton from '../skeletons/HomeFeedSkeleton';

const FADE_DURATION = 180;

export default function HomeFeedContainer() {
  const [data, setData] = useState<HomeFeedItem[] | null>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const isCached = data !== null && data.length > 0;

  useEffect(() => {
    let mounted = true;

    // Simulate API / cache read
    setTimeout(() => {
      if (!mounted) return;

      const feed: HomeFeedItem[] = [
        {
          id: '1',
          type: 'PROMO',
          title: 'Free delivery on medicines',
        },
        {
          id: '2',
          type: 'HEALTH_TIP',
          tip: 'Drink at least 2.5L water daily',
        },
      ];

      setData(feed);

      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: FADE_DURATION,
        useNativeDriver: true,
      }).start();
    }, 600);

    return () => {
      mounted = false;
    };
  }, [fadeAnim]);

  // Cold start → skeleton
  if (!isCached) {
    return <HomeFeedSkeleton />;
  }

  return (
    <Animated.View style={{ opacity: fadeAnim }}>
      <FlatList
        data={data}
        renderItem={({ item }) => <HomeFeedRenderer item={item} />}
        keyExtractor={(item) => item.id}
        scrollEnabled={false}
        removeClippedSubviews
        initialNumToRender={3}
      />
    </Animated.View>
  );
}
