import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useMemo } from 'react';
import {
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { useSelector } from 'react-redux';
import AppIcon from '../../../components/icons/AppIcon';
import { RootState } from '../../../redux/store';

type ServiceItem = {
  id: string;
  title: string;
  icon: string;
  enabled?: boolean;
  background: { start: string; end: string };
  accentColor: string;
};

const SERVICE_NAVIGATION_MAP: Record<
  string,
  { stack: string; params?: Record<string, any> }
> = {
  doctors: { stack: 'DoctorStack' },
  pharmacy: { stack: 'PharmacyStack' },
  labs: { stack: 'LabStack' },
  hospitals: { stack: 'HospitalStack' },
  ambulance: { stack: 'AmbulanceStack' },
  homecare: { stack: 'HomeCareStack' },
};

const SERVICES: ServiceItem[] = [
  {
    id: 'doctors',
    title: 'Doctors',
    icon: 'stethoscope',
    enabled: true,
    accentColor: '#ffffff',
    background: { start: '#4f9cff', end: '#2563eb' },
  },
  {
    id: 'pharmacy',
    title: 'Pharmacy',
    icon: 'pill',
    enabled: true,
    accentColor: '#ffffff',
    background: { start: '#34d399', end: '#059669' },
  },
  {
    id: 'labs',
    title: 'Path Labs',
    icon: 'flask',
    enabled: true,
    accentColor: '#ffffff',
    background: { start: '#fbbf24', end: '#f59e0b' },
  },
  {
    id: 'hospitals',
    title: 'Hospitals',
    icon: 'hospital',
    enabled: true,
    accentColor: '#ffffff',
    background: { start: '#a78bfa', end: '#7c3aed' },
  },
  {
    id: 'ambulance',
    title: 'Ambulance',
    icon: 'ambulance',
    enabled: true,
    accentColor: '#ffffff',
    background: { start: '#fb7185', end: '#e11d48' },
  },
  {
    id: 'homecare',
    title: 'Home Care',
    icon: 'heart',
    enabled: true,
    accentColor: '#ffffff',
    background: { start: '#9ca3af', end: '#6b7280' },
  },
];

function ServicesSection() {
  const navigation = useNavigation<NativeStackNavigationProp<any>>();
  const carts = useSelector((state: RootState) => state.cart);

  // Calculate cart count (number of stores with items) for pharmacy
  const pharmacyCartCount = useMemo(() => {
    const pharmacyCarts = Object.values(carts);
    // Count number of carts (stores) that have items
    return pharmacyCarts.filter(storeCart => 
      Object.keys(storeCart.items).length > 0
    ).length;
  }, [carts]);

  const onPressService = useCallback(
    (item: ServiceItem) => {
      if (!item.enabled) return;
      const target = SERVICE_NAVIGATION_MAP[item.id];
      if (!target) return;
      navigation.navigate(target.stack, target.params);
    },
    [navigation]
  );

  const renderItem = ({ item }: { item: ServiceItem }) => {
    const showCartBadge = item.id === 'pharmacy' && pharmacyCartCount > 0;
    
    return (
      <TouchableOpacity
        style={styles.item}
        activeOpacity={item.enabled ? 0.75 : 1}
        onPress={() => onPressService(item)}
      >
        <LinearGradient
          colors={[item.background.start, item.background.end]}
          style={[
            styles.iconContainer,
            !item.enabled && styles.disabledCard,
          ]}
        >
          <AppIcon
            name={item.icon}
            size={32}
            color={item.accentColor}
          />
              {showCartBadge && (
            <View style={styles.cartBadge}>
              <Text style={styles.cartBadgeText} numberOfLines={1}>
                {pharmacyCartCount > 99 ? '99+' : String(pharmacyCartCount)}
              </Text>
            </View>
          )}
        </LinearGradient>

        <Text
          style={[
            styles.label,
            !item.enabled && styles.disabledText,
          ]}
          numberOfLines={2}
        >
          {item.title}
        </Text>

        {!item.enabled && (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>Coming soon</Text>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>SERVICES</Text>

      <FlatList
        data={SERVICES}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.listContent}
      />
    </View>
  );
}

export default React.memo(ServicesSection);

/* ================= STYLES ================= */

const styles = StyleSheet.create({
  container: {
    marginTop: 24,
    overflow: 'visible',
  },
  title: {
    fontSize: 13,
    color: '#494949',
    marginBottom: 14,
    letterSpacing: 2,
    paddingHorizontal: 20,
  },
  listContent: {
    paddingHorizontal: 26,
  },
  item: {
    width: 76,
    alignItems: 'center',
    marginRight: 14,
    overflow: 'visible',
    paddingTop: 4,
  },
  iconContainer: {
    width: 76,
    height: 76,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
    overflow: 'visible',
  },
  label: {
    fontSize: 13,
    color: '#151517',
    textAlign: 'center',
  },

  /* Disabled State */
  disabledCard: {
    opacity: 0.55,
  },
  disabledText: {
    color: '#9ca3af',
  },

  badge: {
    marginTop: 4,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 999,
    backgroundColor: '#e5e7eb',
  },
  badgeText: {
    fontSize: 10,
    fontWeight: '600',
    color: '#6b7280',
  },
  cartBadge: {
    position: 'absolute',
    top: -6,
    right: -6,
    backgroundColor: '#EF4444',
    borderRadius: 12,
    minWidth: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 8,
    borderWidth: 2,
    borderColor: '#FFFFFF',
    zIndex: 10,
  },
  cartBadgeText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#FFFFFF',
  },
});
