import AppIcon from '@/src/components/icons/AppIcon';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

function UpcomingSection() {
  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <Text style={styles.title}>Upcoming</Text>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text style={styles.seeAll}>See all</Text>
            <AppIcon name='chevron-right' color='#1c1c1e'/> 
        </View>
      </View>
      <View style={styles.cardSection}>
        <View style={styles.card}>
          <Text style={styles.primary}>Dr. Sharma</Text>
          <Text style={styles.secondary}>Today • 5:30 PM</Text>
        </View>
      </View>
    </View>
  );
}

export default React.memo(UpcomingSection);

const styles = StyleSheet.create({
  container: {
    marginTop: 24,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1c1c1e',
  },
  seeAll: {
    fontSize: 14,
    color: '#1c1c1e',
    fontWeight: '600',
  },
  cardSection: {
    paddingHorizontal: 26,
  },
  card: {
    padding: 14,
    borderRadius: 14,
    backgroundColor: '#EEF2FF',
  },
  primary: {
    fontWeight: '600',
    fontSize: 14,
  },
  secondary: {
    fontSize: 12,
    opacity: 0.7,
    marginTop: 4,
  },
});