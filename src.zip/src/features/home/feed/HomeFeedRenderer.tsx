import React from 'react';
import HealthTipCard from './cards/HealthTipCard';
import PromoCard from './cards/PromoCard';
import { HomeFeedItem } from './feed.types';

export default function HomeFeedRenderer({ item }: { item: HomeFeedItem }) {
  switch (item.type) {
    case 'PROMO':
      return <PromoCard data={item} />;
    case 'HEALTH_TIP':
      return <HealthTipCard data={item} />;
    default:
      return null;
  }
}
