import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

function HealthTipCard({ data }: any) {
  return (
    <View style={styles.card}>
      <Text style={styles.title}>{data.tip}</Text>
    </View>
  );
}

export default React.memo(HealthTipCard);

const styles = StyleSheet.create({
  card: {
    marginHorizontal: 16,
    marginBottom: 12,
    padding: 16,
    borderRadius: 16,
    backgroundColor: '#DCFCE7',
  },
  title: {
    fontWeight: '600',
  },
});
