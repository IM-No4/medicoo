export type HomeFeedItemType =
  | 'PROMO'
  | 'HEALTH_TIP'
  | 'REMINDER'
  | 'UPCOMING_APPOINTMENT';

export interface HomeFeedItemBase {
  id: string;
  type: HomeFeedItemType;
}

export interface PromoFeedItem extends HomeFeedItemBase {
  type: 'PROMO';
  title: string;
  subtitle?: string;
  imageUrl?: string;
  ctaText?: string;
}

export interface HealthTipFeedItem extends HomeFeedItemBase {
  type: 'HEALTH_TIP';
  tip: string;
}

export interface ReminderFeedItem extends HomeFeedItemBase {
  type: 'REMINDER';
  text: string;
  dueAt: string;
}

export interface UpcomingAppointmentFeedItem extends HomeFeedItemBase {
  type: 'UPCOMING_APPOINTMENT';
  doctorName: string;
  time: string;
}

export type HomeFeedItem =
  | PromoFeedItem
  | HealthTipFeedItem
  | ReminderFeedItem
  | UpcomingAppointmentFeedItem;
