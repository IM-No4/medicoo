import React, { useState } from 'react';
import { Text, TouchableOpacity, View } from 'react-native';

const slides = [
  'Book doctors instantly',
  'Order medicines easily',
  'Manage your health digitally',
];

export default function IntroScreen({ onFinish }: { onFinish: () => void }) {
  const [index, setIndex] = useState(0);

  return (
    <View style={{ flex: 1, justifyContent: 'center', padding: 20 }}>
      <Text style={{ fontSize: 22, marginBottom: 20 }}>
        {slides[index]}
      </Text>

      <TouchableOpacity
        onPress={() => {
          if (index === slides.length - 1) {
            onFinish();
          } else {
            setIndex(i => i + 1);
          }
        }}
        style={{
          backgroundColor: '#1a998e',
          padding: 14,
          borderRadius: 8,
          marginBottom: 12,
        }}
      >
        <Text style={{ color: '#fff' }}>
          {index === slides.length - 1 ? 'Get Started' : 'Next'}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={onFinish}>
        <Text style={{ textAlign: 'center', color: '#777' }}>Skip</Text>
      </TouchableOpacity>
    </View>
  );
}
