import { useRoute } from '@react-navigation/native';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import {
    Image,
    ScrollView,
    StyleSheet,
    Text,
    View,
} from 'react-native';

export default function RecordDetailScreen() {
  const route = useRoute<any>();
  const { id } = route.params;

  // MOCK record
  const record = {
    id,
    title: 'Blood Test Report',
    date: '12 Aug 2025',
    fileType: 'image', // pdf | image
    uri: 'https://via.placeholder.com/600x800',
  };

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />

      <Text style={styles.title}>
        {record.title}
      </Text>
      <Text style={styles.date}>
        {record.date}
      </Text>

      <ScrollView style={styles.viewer}>
        {record.fileType === 'image' ? (
          <Image
            source={{ uri: record.uri }}
            style={styles.image}
          />
        ) : (
          <Text>PDF viewer placeholder</Text>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
  },
  date: {
    fontSize: 12,
    color: '#6B7280',
    marginBottom: 12,
  },
  viewer: {
    flex: 1,
  },
  image: {
    width: '100%',
    height: 800,
    resizeMode: 'contain',
  },
});
