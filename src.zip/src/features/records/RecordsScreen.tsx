import React, { useMemo, useState } from 'react';
import {
  FlatList,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

type RecordItem = {
  id: string;
  title: string;
  subtitle: string;
  type: string;
  date: string;   // ISO format "2025-01-03"
};

const RECORDS: RecordItem[] = [
  {
    id: '1',
    title: 'Blood Test Report',
    subtitle: 'Apollo Hospital',
    type: 'lab',
    date: '2025-01-28',
  },
  {
    id: '2',
    title: 'X-Ray Scan',
    subtitle: 'City Diagnostics',
    type: 'scan',
    date: '2025-01-10',
  },
  {
    id: '3',
    title: 'Prescription',
    subtitle: 'Dr. Kumar',
    type: 'prescription',
    date: '2024-12-22',
  },
];

const RECORD_TYPES = ['all', 'lab', 'scan', 'prescription'];

export default function RecordsScreen() {
  const [activeType, setActiveType] = useState('all');
  const [search, setSearch] = useState('');

  // ----- New Filters -----
  const [selectedMonth, setSelectedMonth] = useState<string | null>(null);
  const [startDate, setStartDate] = useState<string | null>(null);
  const [endDate, setEndDate] = useState<string | null>(null);

  // Helper: Convert to Date safely
  const parseDate = (d: string) => new Date(d + 'T00:00:00');

  // 🧠 FINAL FILTERED + SORTED DATA
  const filteredRecords = useMemo(() => {
    return RECORDS
      .filter((r) => {
        // type filter
        if (activeType !== 'all' && r.type !== activeType) return false;

        // search filter
        const q = search.toLowerCase();
        if (
          q &&
          !r.title.toLowerCase().includes(q) &&
          !r.subtitle.toLowerCase().includes(q)
        ) {
          return false;
        }

        const recordDate = parseDate(r.date);

        // month filter
        if (selectedMonth) {
          const [yr, mon] = selectedMonth.split('-'); // "2025-01"
          const m = recordDate.getMonth() + 1;
          const y = recordDate.getFullYear();
          if (Number(yr) !== y || Number(mon) !== m) return false;
        }

        // date range filter
        if (startDate && recordDate < parseDate(startDate)) return false;
        if (endDate && recordDate > parseDate(endDate)) return false;

        return true;
      })

      // 🔽 Sort by date (latest first)
      .sort((a, b) => parseDate(b.date).getTime() - parseDate(a.date).getTime());
  }, [activeType, search, selectedMonth, startDate, endDate]);

  return (
    <View style={styles.container}>
      {/* ---------- TYPE FILTER ---------- */}
      <View style={styles.typeRow}>
        {RECORD_TYPES.map((t) => (
          <TouchableOpacity
            key={t}
            onPress={() => setActiveType(t)}
            style={[
              styles.typeBtn,
              activeType === t && styles.typeBtnActive,
            ]}
          >
            <Text
              style={[
                styles.typeText,
                activeType === t && styles.typeTextActive,
              ]}
            >
              {t.toUpperCase()}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* ---------- SEARCH ---------- */}
      <TextInput
        value={search}
        onChangeText={setSearch}
        placeholder="Search records"
        style={styles.input}
      />

      {/* ---------- MONTH FILTER ---------- */}
      <View style={styles.filterRow}>
        <TouchableOpacity
          style={styles.filterBtn}
          onPress={() => setSelectedMonth('2025-01')}
        >
          <Text>January 2025</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.filterBtn}
          onPress={() => setSelectedMonth('2024-12')}
        >
          <Text>December 2024</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.clearBtn}
          onPress={() => setSelectedMonth(null)}
        >
          <Text>Clear Month</Text>
        </TouchableOpacity>
      </View>

      {/* ---------- DATE RANGE FILTER ---------- */}
      <View style={styles.filterRow}>
        <TextInput
          placeholder="Start YYYY-MM-DD"
          value={startDate ?? ''}
          onChangeText={setStartDate}
          style={styles.rangeInput}
        />
        <TextInput
          placeholder="End YYYY-MM-DD"
          value={endDate ?? ''}
          onChangeText={setEndDate}
          style={styles.rangeInput}
        />

        <TouchableOpacity
          style={styles.clearBtn}
          onPress={() => {
            setStartDate(null);
            setEndDate(null);
          }}
        >
          <Text>Clear Range</Text>
        </TouchableOpacity>
      </View>

      {/* ---------- RESULTS LIST ---------- */}
      <FlatList
        data={filteredRecords}
        keyExtractor={(i) => i.id}
        contentContainerStyle={{ paddingTop: 8 }}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.title}>{item.title}</Text>
            <Text style={styles.subtitle}>{item.subtitle}</Text>

            <View style={styles.metaRow}>
              <Text style={styles.tag}>{item.type}</Text>
              <Text style={styles.date}>{item.date}</Text>
            </View>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  typeRow: { flexDirection: 'row', gap: 8 },
  typeBtn: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
  },
  typeBtnActive: { backgroundColor: '#222', borderColor: '#222' },
  typeText: { fontSize: 12 },
  typeTextActive: { color: '#fff' },

  input: {
    marginTop: 12,
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
  },

  filterRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 10,
    flexWrap: 'wrap',
  },

  filterBtn: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderRadius: 10,
  },

  clearBtn: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 10,
    backgroundColor: '#eee',
  },

  rangeInput: {
    borderWidth: 1,
    padding: 8,
    borderRadius: 10,
    minWidth: 120,
  },

  card: {
    marginBottom: 10,
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
  },

  title: { fontWeight: '600', fontSize: 15 },
  subtitle: { marginTop: 4, opacity: 0.6 },

  metaRow: {
    marginTop: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },

  tag: { fontSize: 12, opacity: 0.7 },
  date: { fontSize: 12, opacity: 0.7 },
});
