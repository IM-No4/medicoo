import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { fetchCalendarData } from '../../services/api/calendar.api';

export const loadCalendarData = createAsyncThunk(
  'calendar/load',
  async () => {
    return await fetchCalendarData();
  }
);

interface CalendarState {
  loading: boolean;
  data: any | null;
  error: string | null;
}

const initialState: CalendarState = {
  loading: false,
  data: null,
  error: null,
};

const calendarSlice = createSlice({
  name: 'calendar',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(loadCalendarData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(loadCalendarData.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(loadCalendarData.rejected, (state) => {
        state.loading = false;
        state.error = 'Unable to load calendar';
      });
  },
});

export default calendarSlice.reducer;
