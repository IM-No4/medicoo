import { searchGlobal } from '@/src/services/api/search.api';
import { normalizeSearchResponse } from './normalizers';
import { SearchResult } from './search.types';

export async function globalSearch(
  query: string
): Promise<SearchResult[]> {
  const apiData = await searchGlobal(query);
  return normalizeSearchResponse(apiData);
}
