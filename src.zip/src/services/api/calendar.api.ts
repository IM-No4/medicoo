
/**
 * Get cart on app start
 */
export const fetchCalendarData = async () => {
  return {};
};